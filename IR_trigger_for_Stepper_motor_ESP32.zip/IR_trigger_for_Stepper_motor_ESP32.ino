#include <Stepper.h>

#define STEPS 2048
#define NINETY_DEG (STEPS / 4)  // 90° = 512 steps

const int irPin = 33;       // IR sensor output
const int buzzerPin = 2;    // Buzzer pin

Stepper myStepper(STEPS, 14, 26, 27, 25);

bool isRunning = false;

void setup() {
  pinMode(irPin, INPUT);
  pinMode(buzzerPin, OUTPUT);

  myStepper.setSpeed(15);

  Serial.begin(115200);
  Serial.println("Smart Trash Can Starting...");

  // Home lid on startup
  Serial.println("Homing Lid...");
  myStepper.step(-NINETY_DEG);  
  Serial.println("Lid at Resting Position");
}

void loop() {
  int irState = digitalRead(irPin);

  // 🔹 Inverted logic for active LOW sensor
  if (irState == LOW && !isRunning) {  // Trigger when object is detected
    Serial.println("IR Trigger Detected!");
    isRunning = true;

    // Short buzzer
    digitalWrite(buzzerPin, HIGH);
    delay(500);
    digitalWrite(buzzerPin, LOW);

    // Open lid
    Serial.println("Opening Lid...");
    myStepper.step(NINETY_DEG);

    delay(5000);

    // Close lid
    Serial.println("Closing Lid...");
    myStepper.step(-NINETY_DEG);

    Serial.println("Cycle Complete");
    delay(200);
    isRunning = false;
  }
}